# AI-4GYM

Chatbot Gym tiếng Việt cho người mới: tra cứu bài tập, hỏi kỹ thuật, gợi ý nhóm cơ và lịch tập. Web có đăng ký/đăng nhập để lưu lịch sử hội thoại; khách vẫn chat được nhưng lịch sử sẽ mất khi tải lại trang. AI chạy local bằng **LangChain + RAG + Chroma + Ollama**, không dùng API AI bên ngoài. Tài khoản và hội thoại được lưu trong MySQL local, có thể chạy bằng ServBay.

**Cài từ đầu:** xem [hướng dẫn cài đặt](docs/setup.md). Tài liệu này hướng dẫn phần mềm cần cài, cấu hình ServBay/MySQL, tải model Ollama, tạo chỉ mục và chạy web trên Windows.

## Chạy nhanh sau khi đã cài

Mở hai cửa sổ PowerShell tại thư mục dự án.

**Cửa sổ backend:**

```powershell
Set-Location BE
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

**Cửa sổ frontend:**

```powershell
Set-Location FE
npm run dev
```

Vào [http://127.0.0.1:5173](http://127.0.0.1:5173). Trạng thái hệ thống ở [http://127.0.0.1:8000/health](http://127.0.0.1:8000/health); Swagger API ở [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs). MySQL và Ollama cần đang chạy.

## Tính năng

- Hỏi đáp nhiều lượt về bài tập, kỹ thuật và các lỗi cần tránh.
- Mỗi câu hỏi dùng tối đa 3 lượt hỏi–đáp gần nhất làm ngữ cảnh; câu hỏi nối tiếp được tìm tài liệu theo mạch hội thoại.
- Gợi ý bài tập theo nhóm cơ và lịch tập 1–6 buổi/tuần.
- Điều chỉnh danh sách bài theo dụng cụ, nhóm cơ và một số hạn chế thể chất; mục tiêu gần nhất bổ sung hướng dẫn chung. Yêu cầu lịch có đau vai được giới hạn và khuyên đánh giá y tế.
- Hiển thị nguồn dữ liệu được RAG truy xuất; từ chối câu hỏi ngoài Gym/Fitness.
- Tài khoản lưu lịch sử trong MySQL, có thể mở lại, đổi tên hoặc xóa hội thoại.
- Chế độ khách không ghi lịch sử vào MySQL và xóa cuộc chat khi F5.

## Cấu trúc

Xem [phân chia thư mục và quy tắc giữ file](docs/project-structure.md). [Hồ sơ nộp](reports/HO_SO_NOP.md) và [báo cáo hiện hành](reports/README.md) nằm riêng với bằng chứng/hồ sơ cũ. [Biên bản rà soát báo cáo và docs](docs/report-review.md) ghi phạm vi, kết quả đối chiếu và bàn giao theo phân công.

```text
AI-4GYM/
├── BE/
│   ├── app/
│   │   ├── api/routes/        # HTTP API: auth, chat, hội thoại, danh mục, health
│   │   ├── core/              # cấu hình
│   │   ├── db/                # MySQL: model, session
│   │   ├── services/          # RAG, dữ liệu, lịch tập, kiểm tra phạm vi
│   │   ├── scripts/           # init_db, ingest, đánh giá chatbot, xuất Excel
│   │   └── main.py            # FastAPI và phục vụ FE/dist
│   ├── data/
│   │   ├── raw/data.xlsx
│   │   ├── processed/qa.json
│   │   ├── processed/train.json
│   │   ├── processed/test.json
│   │   ├── processed/split_manifest.json
│   │   ├── curated/exercises.json
│   │   └── index/chroma/      # tạo local, không đưa lên Git
│   ├── tests/
│   ├── .env.example
│   └── requirements.txt
├── FE/
│   ├── src/components/
│   ├── src/lib/api.ts
│   ├── src/App.tsx
│   └── package.json
├── reports/
│   ├── Tieu_luan_AI_4GYM_CT07PM.docx / .pdf  # tiểu luận hoàn chỉnh
│   ├── Bao_cao_kiem_thu_AI_4GYM.docx / .pdf   # báo cáo kiểm thử
│   ├── Bo_kiem_thu_AI_4GYM.xlsx              # ma trận ca và kết quả
│   ├── results/                            # JSON/TXT kiểm thử mới, rà soát AI
│   ├── evidence/                           # ảnh thật, sơ đồ, môi trường
│   ├── history/                            # hồ sơ kỹ thuật cũ
│   ├── tools/                              # tạo/kiểm tra/đóng gói báo cáo
│   ├── releases/                           # ZIP hồ sơ nộp đầy đủ
│   ├── AI-4GYM_train_test_report.xlsx       # train/test 193 câu bàn giao
│   └── evaluation_results.jsonl
├── docs/setup.md                           # cài đặt và chạy ứng dụng
└── README.md
```

## Dữ liệu

`BE/data/raw/data.xlsx` có **965 cặp hỏi đáp**; `BE/data/processed/qa.json` là bản chuyển đổi đầy đủ sang JSON, có số thứ tự và dòng Excel. Dữ liệu được chia cố định theo câu hỏi đã chuẩn hóa:

| Tập dữ liệu | File | Số câu | Tỷ lệ | Cách dùng |
| --- | --- | ---: | ---: | --- |
| Train/corpus | `BE/data/processed/train.json` | 772 | 80% | Lập chỉ mục RAG trong Chroma |
| Test | `BE/data/processed/test.json` | 193 | 20% | Giữ riêng để kiểm tra, không lập chỉ mục |

`BE/data/processed/split_manifest.json` ghi seed, số lượng và tỷ lệ. Các câu hỏi trùng sau chuẩn hóa nằm cùng một tập. Thêm 11 bài tập có liên kết đến [ACE Exercise Library](https://www.acefitness.org/resources/everyone/exercise-library/) vào corpus, nên Chroma có **783 tài liệu**. Không phải mọi bài đều được ACE xếp mức Beginner. Excel hiện hành đã có nguồn theo từng câu (676/965 câu dẫn tới bộ dữ liệu fitness-question-answers trên Hugging Face); URL nguồn giúp truy vết, chưa đồng nghĩa mọi nội dung đã được chuyên gia thẩm định.

Phép chia ngăn câu hỏi trùng sau chuẩn hóa xuất hiện ở cả hai tập; các câu diễn đạt khác nhau nhưng cùng ý chưa được nhóm tự động.

**Lưu ý cho báo cáo:** “80% train” ở đây là dữ liệu dùng để xây dựng kho truy xuất; dự án **không fine-tune/huấn luyện lại** model Qwen hay model embedding. RAG lấy tài liệu khi trả lời, theo [mô tả của LangChain](https://docs.langchain.com/oss/python/deepagents/retrieval). Tập test 20% chưa đồng nghĩa độ chính xác 20% hay bất kỳ chỉ số chất lượng nào.

Hồ sơ bàn giao có 193/193 câu được chấm: **132 câu 2/2, 56 câu 1/2, 5 câu 0/2**; 154 dòng dùng judge v2, 39 dòng dùng v3. Excel có 187 nhãn tay đạt/6 không đạt, chưa được chuyên gia độc lập xác minh. Đây là số liệu trước đợt sửa lỗi 25/11/2026, không phải kết quả đo lại toàn bộ phiên bản mới. Xem [bộ báo cáo hiện tại](reports/README.md) để đọc kiểm thử mới và giới hạn. Chatbot hỗ trợ tham khảo, không thay thế đánh giá chuyên môn khi có chấn thương hoặc bệnh lý.

Log ngày 25/11/2026 ghi **53/53 phương thức backend và 10/10 kịch bản Edge đạt**. Bộ hỏi mới gồm 12 tình huống/16 lượt, đạt điều kiện chức năng nhưng còn 6 cờ rà soát nội dung. Năm lượt RAG có thời gian ChatService trung bình **85,205 giây**, không gồm judge; mẫu này được tách khỏi 193 bản ghi cũ. Đây là kết quả đã lưu, không phải một lần chạy lại khi cập nhật tài liệu.

### Báo cáo Excel

[Báo cáo và bộ kiểm thử hiện tại](reports/README.md) ghi kết quả thực thi, số liệu đánh giá và giới hạn. Chạy lệnh kiểm toán bên dưới để xem trạng thái mới nhất trực tiếp từ file.

[Bàn giao Security, Evaluation & Performance](reports/history/SECURITY_PERFORMANCE.md) ghi test prompt injection, session/replay, chấm lại câu 20 và phép đo độ trễ local.

[Mở báo cáo train/test](reports/AI-4GYM_train_test_report.xlsx) để xem tổng quan, danh sách 772 câu train, 193 câu test và kết quả chatbot trên từng câu test. Sheet `Danh gia Test` ghi câu trả lời thực tế, điểm Qwen local (0–2), lý do chấm, Token F1, ROUGE-L F1, nguồn RAG và thời gian ghi cũ. Trường thời gian cũ có thể gồm cả judge, không dùng làm độ trễ chatbot. Điểm 2 là đạt, 1 là đúng một phần, 0 là sai hoặc từ chối. Tỷ lệ đạt tự động = số câu điểm 2 / số câu đã chạy; chỉ khi chạy đủ 193 câu mới là kết quả toàn bộ tập test. Có thêm cột `Duyệt tay (1/0)` để kiểm tra độc lập.

**Cách chạy đánh giá đầy đủ** tại `BE/`:

```powershell
.\.venv\Scripts\python.exe -m app.scripts.evaluate_chatbot
```

Lệnh gọi đúng `ChatService` đang phục vụ web trên từng câu test độc lập, sau đó dùng Qwen local chấm theo đáp án tham chiếu và xuất Excel. Kết quả từng câu được lưu vào `reports/evaluation_results.jsonl`. Hiện 193 câu đã có điểm; chạy lại lệnh này sẽ **chấm lại 154 dòng judge v2 bằng judge v3** trên câu trả lời đã lưu, làm thay đổi thống kê. Dùng `--ids` nếu chỉ muốn kiểm tra vài câu. Không dùng API AI bên ngoài. Điểm AI là đánh giá tự động bởi cùng họ model đang trả lời, vì vậy nên rà soát độc lập trước khi trình bày như một tỷ lệ chính xác được xác minh. Token F1 và ROUGE-L chỉ đo trùng từ, không tự chứng minh đúng sai. Bộ hỏi mới sau sửa lỗi được lưu riêng trong `reports/results/chatbot_ai_review.json`.

Để tạo lại file sau khi chạy `ingest` với dữ liệu mới, đứng tại `BE/` và chạy:

```powershell
.\.venv\Scripts\python.exe -m app.scripts.export_report
```

Lệnh xuất Excel từ kết quả đã lưu mà không chạy lại chatbot. Cả hai lệnh kiểm tra dữ liệu gốc, phép chia train/test và chỉ mục Chroma. Nếu chỉ mục chưa có hoặc đã cũ, chạy `python -m app.scripts.ingest` trước.

## Kiểm tra

```powershell
# Tại BE/, khi MySQL và Ollama đang chạy
.\.venv\Scripts\python.exe -m unittest discover -s tests -v

# Kiểm tra Excel gốc, JSON, phép chia và báo cáo; không cần MySQL/Ollama
.\.venv\Scripts\python.exe -m app.scripts.audit_report

# Tại FE/
npm run build
```

Xem [hướng dẫn cài đặt](docs/setup.md) nếu cần cài mới hoặc xử lý lỗi khi chạy.
